

=== WooCommerce - factureaza.ro ===
Contributors: factureaza.ro
Tags: shipping, woocommerce
Requires at least: 5.4
Requires PHP: 7.2
Tested up to: 6.1
Stable tag: 1.3.5
Author: Factureaza
Author URI: www.factureaza.ro
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin de facturare WooCommerce pentru [factureaza.ro](https://factureaza.ro).

== Descriere ==

Folosind plugin-ul nostru pentru WooCommerce poţi emite şi trimite facturile pentru comenzile magazinului tău online.
Facturile vor fi generate pe site-ul [factureaza.ro](https://factureaza.ro) în contul tău.

[Click](https://factureaza.ro/ajutor/modulul-woocommerce-pentru-magazine-online) aici pentru a accesa tutorialul nostru de instalare.

Plugin-ul nostru se bazează pe un serviciu extern. Preluăm datele de pe website-ul tău şi le trimitem prin API pentru a genera facturi.
Website link: [factureaza.ro](https://factureaza.ro)
[Termeni și condiții](https://factureaza.ro/termeni-si-conditii)
[Politica de confidențialitate și acordul de prelucrare a datelor](https://factureaza.ro/politica-de-confidentialitate)

*   Ai nevoie de minim WordPress 4.7.0 şi WooCommerce 3.0.0.
*   Testat până la WordPress versiunea 6.1 şi WooCommerce 7.2.

== Instalare ==

1. Instalează plugin-ul din dashboard-ul WordPress din secțiunea Plugins sau uploadează `f4.zip` în folder-ul `/wp-content/plugins/`.
2. Activează plugin-ul din tab-ul 'Plugins' din dashboard-ul WordPress.
3. Loghează-te cu api key-ul generat pe [factureaza.ro](https://factureaza.ro).
4. Poți configura plugin-ul din tab-ul Settings.

== Frequently Asked Questions ==

= Cum pot schimba starea facturii? =

Starea de bază a facturii generate este "ca emisă" dar din tab-ul Settings poți bifa căsuța document state, iar următoarele
facturi generate vor avea starea "ca ciornă".

= Configurare pentru persoane juridice =

[Tutorial configurare woocommerce pentru persoane juridice](https://factureaza.ro/ajutor/configurare-woocommerce-pentru-persoane-juridice)

== Screenshots ==

1. Homepage of plugin.
`/factureaza-homepage`

== Changelog ==
Ready to deploy!

= 1.3.5 =
* company buyer name se poate modifica din setări
= 0.9.8 =
* am rezolvat bug-ul cu tva-ul, am adăugat company name label
= 0.9.7 =
* generic fallback client exists - funcție care verifică dacă clientul există deja
= 0.9.6 =
* am rezolvat bug-ul cu identificarea cliențiilor în funcția client_exists
= 0.9.5 =
* am rezulvat bug-ul prețul se împarțea la 0
= 0.9.4 =
* am rezolvat bug-ul cu conversia product lines din float în string
= 0.9.1 =
* testat pt versiunea 6.0 de WordPress
= 0.9.0 =
* proforma_invoices ar trebui să se genereze fără bug-uri la fel ca invoices

== Upgrade Notice ==

= 1.3.5 =
Company buyer name se poate modifica din setări

== Secțiune arbitrară ==

Folosim API-ul GraphQL pus la dispoziţie de [factureaza.ro](https://factureaza.ro).
