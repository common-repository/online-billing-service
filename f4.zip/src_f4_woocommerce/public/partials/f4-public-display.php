<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
