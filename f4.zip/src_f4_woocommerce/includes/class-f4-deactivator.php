<?php

/**
 * Fired during plugin activation
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.3.5
 * @package    F4
 * @subpackage F4/includes
 * @author     F4 <office@factureaza.ro>
 */
class F4_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.3.5
	 */
	public static function deactivate() {

	}

}

?>
