<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.3.5
 * @package    F4
 * @subpackage F4/includes
 * @author     F4 <office@factureaza.ro>
 */
class F4_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.3.5
	 */
	public function load_plugin_textdomain() {
		load_plugin_textdomain(
			'f4',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}
}

?>
