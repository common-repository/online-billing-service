<?php

 include_once 'f4-initializers.php';

class F4_User {
    public static function get_user_id() {
		$query_string = '{ users { id } }';
		$users_response = F4_Admin_Query::query(F4_Admin_Authentication::global_api_key(), $query_string);

		if(!is_wp_error($users_response)) {
			$users_json = json_decode($users_response['body'], true);
			$user = $users_json['data']['users'][0]['id'];
		}

		if(!empty($user)) { return $user; }
	}
}

?>
