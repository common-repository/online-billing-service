<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<?php 
	require_once plugin_dir_path( __FILE__ ) . '../class-f4-admin-authentication.php';
	F4_Admin_Authentication::set_api_key();

?>
