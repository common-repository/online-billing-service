<?php
    include_once plugin_dir_path( dirname( __FILE__ ) ) . '/class-f4-admin-authentication.php';
    $api_key = F4_Admin_Authentication::global_api_key()
?>

<div class="wrap">
    
    <?php
        $logo_path = plugin_dir_url( dirname( __FILE__ ) ) . 'images/logo-f4.png';
    ?>
    <img src="<?php _e($logo_path); ?>" alt="factureaza.ro" class="f4-image-logo" />

    <?php 
        if(!empty($api_key)) {
            _e("<form method=\"post\" class=\"f4-collapsible\">");
        } else {
            _e("<form method=\"post\">");
        };
    ?>

    <form method="post" class="f4-collapsible">
    	<input id="api_key" name="api_key" type="text" placeholder="Api Key" required />
        <input name="Submit" type="submit" class="button button-primary" value="<?php _e('Authentication', 'f4'); ?>" />
    </form>

    <h2>
        <?php 
            if(!empty($api_key) && current_user_can('administrator')) {
                _e("<a href=\"#\" id=\"f4changeapikey\"> Change api key </a>");
            };
        ?>
    </h2>
</div>
