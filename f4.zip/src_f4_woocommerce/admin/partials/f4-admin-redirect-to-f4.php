<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/admin/partials
 */
?>

<?php
    global $wpdb;
    $f4 = $wpdb->prefix . "wc_f4_settings";
    $results = $wpdb->get_results( "SELECT * FROM " . $f4 . " ORDER BY id DESC LIMIT 1", OBJECT );

    if(!empty($results[0]->custom_redirect)) {
        $custom_redirect = $results[0]->custom_redirect;
        $url = '//' . $custom_redirect;
    } else {
        $url = admin_url( 'admin.php?page=f4-admin' );           
    }
?>

<script>
    window.location="<?php _e($url); ?>";
</script>

<?php exit; ?>
