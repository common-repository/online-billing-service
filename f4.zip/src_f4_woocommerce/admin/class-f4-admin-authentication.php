<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    F4
 * @subpackage F4/admin
 * @author     F4 <office@factureaza.ro>
 */

define('FAC_WOO_F4_SALT', 'UHRCJKZONZFLQCUAHDCNKRKYEJZIFTUA');

class F4_Admin_Authentication {
	public static function crypt_api_key( $api_key, $action = 'e' ) {
		global $wpdb;
	    $f4 = "REWSAKSDNSFFQYUFHALNOMKNEPZIOPLW";
	    $results = $wpdb->get_results( "SELECT * FROM " . $f4 . " ORDER BY id ASC LIMIT 1", OBJECT );
	    $secret_key = $results[0]->sk;
	    $secret_iv = $results[0]->s4;
	    $output = false;
	    $encrypt_method = "AES-256-CBC";
	    $key = hash( 'sha256', $secret_key );
	    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

	    if( $action == 'e' ) {
	        $output = openssl_encrypt( $api_key . FAC_WOO_F4_SALT, $encrypt_method, $key, 0, $iv );

			if(empty($output)) {
                $output = self::customF4Encrypt($api_key . FAC_WOO_F4_SALT, $key);
				global $wpdb;
				$f4 = $wpdb->prefix . "wc_f4_api_key";
				$results = $wpdb->get_results( "SELECT * FROM " . $f4 . " ORDER BY id DESC LIMIT 1", OBJECT );

				$wpdb->insert(
					$f4,
					array(
						'api_key' => $results[0]->api_key,
						'encryption_type' => 'f4_custom_enc'
					)
				);
                $encrypt_type = 'f4_custom_enc' ?? null;
            }
	    } else if( $action == 'd' ){
			global $wpdb;
			$f4 = $wpdb->prefix . "wc_f4_api_key";
			$results = $wpdb->get_results( "SELECT * FROM " . $f4 . " ORDER BY id DESC LIMIT 1", OBJECT );

			if(!empty($results) && !empty($results[0])) {
                $encrypt_type = $results[0]->encryption_type ?? null;
            }

			if(!empty($encrypt_type) && $encrypt_type == 'f4_custom_enc') {
                $output = self::customF4Decrypt($results[0]->api_key, $key);
                $output = str_replace(FAC_WOO_F4_SALT, '', $output);
            } else {
                $output = openssl_decrypt( $api_key, $encrypt_method, $key, 0, $iv );
                $output = str_replace(FAC_WOO_F4_SALT, '', $output);
            }
	    }

		if(empty($encrypt_type)) { $encrypt_type = null; }
	    return [$output, $encrypt_type];
	}

	public static function set_api_key() {
		if (!woocommerce_presnece()) {
            woocommerce_absent_error();
        }

		if(current_user_can('administrator')) {
			require_once plugin_dir_path( __FILE__ ) . '/partials/f4-admin-authentication-form.php';

			global $wpdb;
			$f4 = $wpdb->prefix . "wc_f4_api_key";

			if(isset($_POST['api_key'])) {
				$f4_api_key = sanitize_text_field($_POST['api_key']);
				$crypt_api_key_and_type = self::crypt_api_key($f4_api_key, 'e');
				$results = $wpdb->get_results( "SELECT * FROM " . $f4 . " WHERE api_key ='" . $crypt_api_key_and_type[0] . "'", OBJECT );
			    self::api_key_is_empty(self::crypt_api_key($crypt_api_key_and_type[0], 'd'));

				$wpdb->insert(
					$f4,
					array(
						'api_key' => $crypt_api_key_and_type[0],
						'encryption_type' => $crypt_api_key_and_type[1]
					)
				);

				foreach ($results as $result) {
					if($result->api_key == $f4_api_key) {
						print_r(esc_html($result->api_key));
						_e("<br>");
					}
				}

			}
			self::api_key_is_empty(self::global_api_key());
		}

		require_once plugin_dir_path( __FILE__ ) . 'class-f4-admin-query.php';
		require_once plugin_dir_path( __FILE__ ) . 'class-f4-admin-orders.php';

		if(self::global_api_key()) {
			F4_Admin_Query::display_queries();
		}
	}

	public static function api_key_is_empty($api_key) {
		if(empty($api_key)) {
			_e("<h3 class=\"f4\"> Please add an api key! </h3>");
			return;
		}
	}

	public static function global_api_key() {
		$api_key = NULL;
		global $wpdb;
		$f4 = $wpdb->prefix . "wc_f4_api_key";

		$results = $wpdb->get_results( "SELECT * FROM " . $f4 . " ORDER BY id DESC LIMIT 1", OBJECT );

		if(!empty($results[0])) {
			if(!empty($results[0]->api_key)) {
				$api_key = self::crypt_api_key($results[0]->api_key, 'd')[0];
			}
		}
		return $api_key;
	}

	function customF4Encrypt($string, $key=FAC_WOO_F4_SALT) {
        $result = '';
        for($i=0, $k= strlen($string); $i<$k; $i++) {
            $char = substr($string, $i, 1);
            $keychar = substr($key, ($i % strlen($key))-1, 1);
            $char = chr(ord($char)+ord($keychar));
            $result .= $char;
        }
        return base64_encode($result);
    }

    function customF4Decrypt($string, $key=FAC_WOO_F4_SALT) {
        $result = '';
        $string = base64_decode($string);
        for($i=0,$k=strlen($string); $i< $k ; $i++) {
            $char = substr($string, $i, 1);
            $keychar = substr($key, ($i % strlen($key))-1, 1);
            $char = chr(ord($char)-ord($keychar));
            $result .= $char;
        }
        return $result;
    }
}

?>
