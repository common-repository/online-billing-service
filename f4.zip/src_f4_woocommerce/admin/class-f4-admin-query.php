<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    F4
 * @subpackage F4/admin
 * @author     F4 <office@factureaza.ro>
 */

include_once 'class-f4-admin-authentication.php';
// include_once 'models/f4-account.php';
// include_once 'models/f4-client.php';
// include_once 'models/f4-invoice.php';
// include_once 'models/f4-invoice-series.php';
// include_once 'models/f4-user.php';

$models = glob(plugin_dir_path( __FILE__ ) . 'models/*.php');                                                                                                            
foreach($models as $model) {                                                                                                                                             
	if($model != __FILE__) {                                                                                                                                               
		include_once $model;                                                                                                                                                 
	}                                                                                                                                                                      
}   

define('FAC_WOO_F4_URL', 'https://factureaza.ro');
define('FAC_WOO_F4_SHARED_DOCUMENT_TLD', 'vizualizare');
define('FAC_WOO_F4_ERRORS_LOG', plugin_dir_path( __FILE__ ) . 'fac-woo-f4-queries.log');
define('FAC_WOO_F4_SIMILAR_CLIENT_PERCENTAGE_ACCEPTED', 83.5);

class F4_Admin_Query {					
	public static function query( $api_key, $query_string ) {
		$url = FAC_WOO_F4_URL . '/graphql';
		$body = '{"query": "' . $query_string .  '"}';
		$args = array(
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $api_key . ':x' ),
				'Content-Type' => 'application/json'
			),
			'timeout' => 45,
			'body' => $body
		);

		// try to catch all errors on query and display them right here 
		$response = self::execute_request($url, $args);
		self::parse_query_errors($response);
		return $response;
	}

	public static function execute_request($url, $args) {
		try {
			$response = wp_remote_post( $url, $args );
		} catch (Exception $e) {
			_e('<h3 class="f4-custom-error">');
			_e('Caught exception: ',  $e->getMessage(), "\n");
			_e("<br>");
			_e("key: " . F4_Admin_Authentication::global_api_key());
			_e("<br>");
			_e("query: " . $query_string);
			_e('</h3>');
			return;
		}

		if(!empty($response)) {
			return $response;
		}
	}

	public static function parse_query_errors($response) {
		_e('<h3 class="f4-custom-error">');
		if(is_wp_error($response)) {
			_e('$response is a WP_ERROR');
			_e("<br>");
			return;
		} 

		if(empty($response)) {
			_e('$response is empty');
			_e("<br>");
			return;
		}
		
		if(!empty($response)) {
			$response_body = json_decode($response['body'], true);
			if(!empty($response_body)) {
				if(!empty($response_body['error'])) {
					_e($response_body['error']['message']);
					_e("<br>");
					return;
				}
				
				if(!empty($response_body['errors'])) {
					_e($response_body['errors'][0]['message']);
					_e("<br>");
					return;
				}

				if(!empty($response_body['message'])) {
					_e($response_body['message']);
					_e("<br>");
					return;
				}
			}
		}
		_e('</h3>');
		return $response;
	}

	public static function display_queries($invoice_type = null) {
		if ( !self::f4_wc_stripe_integration_workflow() ) {
			F4_Account::account_informations();
			F4_Invoice::generate_one_invoice($invoice_type);
			F4_Invoice::generate_batch_invoices($invoice_type);
			// self::generate_all_invoices();
			F4_Invoice::display_invoices();
		}
	}

	public static function f4_wc_stripe_integration_workflow() {
		global $wpdb;
		$f4 = $wpdb->prefix . "wc_f4_settings";
		$results = $wpdb->get_results( "SELECT * FROM " . $f4 . " ORDER BY id DESC LIMIT 1", OBJECT );

		if(!empty($results[0])) {
			$stripe_integration_workflow = !empty($results[0]->stripe_integration_workflow) ? true : false;
		} else {
			$stripe_integration_workflow = false;
		}

		return $stripe_integration_workflow;
	}
}

?>
