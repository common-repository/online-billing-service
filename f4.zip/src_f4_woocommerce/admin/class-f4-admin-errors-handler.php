<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       factureaza.ro
 * @since      1.3.5
 *
 * @package    F4
 * @subpackage F4/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    F4
 * @subpackage F4/admin
 * @author     F4 <office@factureaza.ro>
 */

class F4_Admin_Errors_Handler {
    public static function handle_errors($fields) {
        if(self::invoice_series_settings_error($fields)) {
            return 'invoice_series_settings_error';
        }
    }

    public static function invoice_series_settings_error($fields) {
        if(!empty($_POST)) {
            $post_custom_series_prefix = !empty($_POST['custom_series_prefix']) ? sanitize_text_field($_POST['custom_series_prefix']) : '';
            $post_custom_series_suffix = !empty($_POST['custom_series_suffix']) ? sanitize_text_field($_POST['custom_series_suffix']) : '';
            $post_stripe_integration_workflow = $_POST['stripe_integration_workflow'] ?? 0;

            foreach ($fields as $field) {
                if(empty($fields)) {
                    $field = 0;
                } else {
                    if($field) {
                        $field = 1;
                    } else {
                        $field = 0;
                    }
                }
            }

            if(empty($fields)) {
                $field = 0;
            }

            $post_stripe_integration_workflow = $post_stripe_integration_workflow ?? $field;
            if((empty($post_custom_series_prefix) && empty($post_custom_series_suffix)) && !$post_stripe_integration_workflow) {
                return true;
            }
        }
    }
}

?>
